import './bootstrap';
import toastr from 'toastr';
import 'toastr/build/toastr.min.css';
import Swal from 'sweetalert2/dist/sweetalert2.js';

