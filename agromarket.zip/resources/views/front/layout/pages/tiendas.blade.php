@section('content')
<div class="container py-5">
    <h2 class="text-center mb-4">Tiendas registradas</h2>
    <div class="row">
        @forelse($tiendas as $tienda)
        <div class="col-md-4 mb-4">
            <div class="card h-100 text-center">
                <img src="{{ asset('images/shops/' . $tienda->shop_logo) }}" class="card-img-top mx-auto mt-3" alt="{{ $tienda->shop_name }}" style="max-width: 150px;">
                <div class="card-body">
                    <h5 class="card-title">{{ $tienda->shop_name }}</h5>
                    <p class="card-text">{{ Str::limit($tienda->shop_description, 100) }}</p>
                </div>
                <div class="card-footer">
                    <a href="{{ route('tienda.detalle', $tienda->id) }}" class="btn btn-primary btn-sm">Ver tienda</a>
                </div>
            </div>
        </div>
        @empty
        <p class="text-center">No hay tiendas registradas aún.</p>
        @endforelse
    </div>
</div>
@endsection
