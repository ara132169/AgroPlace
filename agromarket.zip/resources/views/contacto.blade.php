@extends('front.layout.pages-contacto')
@section('pageTitle', isset($pageTitle) ? $pageTitle : 'AgroMarketPlace - Contacto')
@section('content')

--Contenido--
@endsection