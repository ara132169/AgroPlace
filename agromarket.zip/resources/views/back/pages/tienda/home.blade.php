@extends('back.layout.pages-layout')
@section('PageTitle',isset($pageTitle)? $pageTitle : 'Agro MarketPlace')
@section('content')
sección administrador / vistas ventas
@endsection
