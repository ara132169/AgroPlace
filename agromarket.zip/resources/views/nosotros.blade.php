@extends('front.layout.pages-nosotros')
@section('pageTitle', isset($pageTitle) ? $pageTitle : 'AgroMarketPlace - Nosotros')
@section('content')

--Contenido--
@endsection