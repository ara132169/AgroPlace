@extends('front.layout.pages-layout')
@section('pageTitle', isset($pageTitle) ? $pageTitle : 'Agro-MarketPlace')
@section('content')

--Contenido--
@endsection