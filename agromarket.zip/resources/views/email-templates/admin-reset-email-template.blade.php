<p>Estimado {{$admin->name}}</p><br>
<p>
    Su contraseña de agromarketplace.com ha sido cambiada satisfactoriamente.
    Aquí están tus credenciales de inicio de sesión: <br>
    <b>Usuario:</b>{{$admin->username}} or {{$admin->email}}
    <br>
    <b>Contraseña:</b>{{$new_password}}

</p><br>
Mantén tus credenciales de inicio de sesión en un lugar seguro. No lo compartas con nadie.

<br>
---------------------------------------------------
<p>
    Este correo fue generado automaticamente desde la plataforma de agromarketplace. Favor de no responder.
</p>