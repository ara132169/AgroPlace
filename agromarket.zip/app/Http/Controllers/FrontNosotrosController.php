<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FrontNosotrosController extends Controller
{
   
}
